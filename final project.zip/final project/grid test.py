from graphics import *
from time import*
from random import*
from memory import*



def main():
    win = GraphWin("word cloud", 800, 800)
    Memory = memory()
    
    win.setBackground("lightsteelblue1")
    ptList = []



    for x in range (50,800,80): #Use the length of the longest word to find out the suitable space
            for y in range (50,800,100): #The height doesn't matter much because the letters are given in a certain range.
                ptList.append(Point(x,y))  #Append new points to the list
   
    for point in ptList:
        point.draw(win)
    for i in range(3):
        memory.initDeal(win, 200, 500)
        
        
        
    
main()
