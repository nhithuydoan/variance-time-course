from Deck import*
from PlayingCard import*
from graphics import*


class memory:
      
    def __init__(self, Hand=[]):
            #constructor that initializes instance variables
            #it also gives the playingDeck an initial shuffle
        self.Hand = Hand
        self.deck = Deck()
        self.deck.shuffle()
        self.images = []  #To undraw the cards when the game is done
        
    def initDeal(self,win,xpos, ypos):
            #deals out initial cards, 2 per player and 
            #displays dealer and player hands on graphical win
            #xposD and yposD give initial position for dealer cards
            #xposP and yposP are analogous
        
        self.Hand.append(self.deck.dealCard()) #card 1
        self.Hand.append(self.deck.dealCard()) #card 2
        self.Hand.append(self.deck.dealCard()) #card 3
        
    
##        dHiddenCard = Image(Point(xposD, yposD) , "playingcards/b1fv.gif")
##        dHiddenCard.draw(win)
##        self.images.append(dHiddenCard) #Draw the back of the card on top of the first card


        for i in range(3):
            
            cardRank = self.Hand[i].getRank()
            cardSuit = self.Hand[i].getSuit()
            file = "playingcards/" + cardSuit + str(cardRank) + ".gif"
            Card = Image(Point(xposD + 100, yposD) , file)
            Card.draw(win)
            self.images.append(Card)
            xpos = xpos + 100
        
        
        
        
        
                    
    def hit(self, win, xPos, yPos):
        
            #adds a new card to the player's hand and places it at xPos, yPos
        playerCard = self.deck.dealCard()
        self.pHand.append(playerCard)
        cardRank = playerCard.getRank()
        cardSuit = playerCard.getSuit()
        file = "playingcards/" + cardSuit + str(cardRank) + ".gif"
        pImage = Image(Point(xPos, yPos) , file)
        pImage.draw(win)
        self.images.append(pImage)

        
        
            
    def dealerPlays(self, win, xPos, yPos):
            #dealer deals cards to herself, stopping when hitting "soft 17"
        dealerCard = self.deck.dealCard()
        self.dHand.append(dealerCard)
        dCardRank = dealerCard.getRank()
        dCardSuit = dealerCard.getSuit()
        file = "playingcards/" + dCardSuit + str(dCardRank) + ".gif"
        dImage = Image(Point(xPos, yPos) , file)
        dImage.draw(win)
        self.images.append(dImage)
        
    def dealerFlip(self, win, xPos, yPos): #When the player hits stand, the first card of  dealer is flipped
        cardRank = self.dHand[0].getRank()
        cardSuit = self.dHand[0].getSuit()
        file = "playingcards/" + cardSuit + str(cardRank) + ".gif"
        dImage = Image(Point(xPos , yPos) , file)
        dImage.draw(win)
        self.images.append(dImage)
        

    def renewWin(self):
        for card in self.images:
            card.undraw()

        #Restart everything again
        self.images = []
        self.pHand = []
        self.dHand = []
        self.deck = Deck()
        self.deck.shuffle()

        
























        
        
    
